import typer
from typing_extensions import Annotated

def bean_import(
    file: Annotated[str, typer.Argument(help="The file to parse")]
):
    print(f"Parsing: {file}")
